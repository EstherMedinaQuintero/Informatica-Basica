#include <fstream>
#include <string>

void Usage(int argc, char* argv[]); 
void SwapLine(const std::string& input_file_name, const std::string& output_file_name);
std::string InvertString(const std::string& string_to_invert);
//std::string KHelpText = "To use this program you must put the name of the input file and the name of the output file.";