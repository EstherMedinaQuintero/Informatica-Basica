/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Omar Suárez Doro alu0101483474@ull.edu.es
 * @date 16 Dic 2021
 * @brief This program prints the word which has the higher number of vowels and
 * which has the higher number of consonants in a file.
 * @bug No bugs know
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include <iostream>
#include <string>

#include "ejercicio_evaluacion.h"

int main(int argc, char* argv[]) {
  Usage(argc, argv);
  std::string input_file_name = argv[1];
  std::string output_file_name = argv[2];
  SwapLine(input_file_name, output_file_name);
}