#include <iostream>
#include <fstream>
#include <string>

#include "ejercicio_evaluacion.h"

/**
 * This function insert each string inverted of the input file into the output file.
 *
 * @param input_file_name : name of the input file
 * @param output_file_name : name of the output file
 * @return Anything
 */
void SwapLine(const std::string& input_file_name, const std::string& output_file_name) {
  std::ifstream input_file{input_file_name, std::ios_base::in};
  std::ofstream output_file{output_file_name, std::ios_base::app};
  std::string string_to_invert;
  while (input_file >> string_to_invert) {
    output_file << (InvertString(string_to_invert) + " ");
  }
}
/**
 * This function invert the strings of the input file
 *
 * @param string_to_invert : the string to invert.
 * @return string_inverted : the inverted string
 */
std::string InvertString(const std::string& string_to_invert) {
  int counter = string_to_invert.length() - 1;
  std::string string_inverted{string_to_invert};
  for (const auto& element_of_string : string_to_invert) {
    string_inverted.at(counter) = element_of_string; 
    counter--;
  }
  return string_inverted;
}

/** This function shows the correct use of the program.
 *  Otherwise, shows the message and close the execution of the program.
 *  @param[in] argc Number of command line parameters
 *  @param[in] argv Vector containing (char*) the parameters
 */
void Usage(int argc, char* argv[]) {
  if (argc != 3) {
    std::cout << argv[0] << ": Parameters missing." << std::endl;
    std::cout << "Try " << argv[0] << " --help for more information"
              << std::endl;
    exit(EXIT_SUCCESS);
  }
  std::string parameter{argv[1]};
  if (parameter == "--help") {
    //std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
}